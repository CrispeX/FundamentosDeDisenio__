# Althea Gestión Turística

## Ejecutar

```
node server.js
```

Abrir http://localhost:3000

## Estructura

```
althea-viajes/
├── server.js                      # Arranque del servidor HTTP y archivos estáticos
├── package.json
├── data/db.json                   # Persistencia (JSON)
├── src/
│   ├── config/index.js            # Puerto, rutas, tipos MIME
│   ├── routes/index.js            # Tabla de rutas /api
│   ├── controllers/               # Capa HTTP
│   ├── services/                  # Lógica de negocio y validaciones
│   ├── models/db.js               # Acceso a datos
│   └── utils/                     # Errores y helpers HTTP
└── public/
    ├── index.html
    ├── css/styles.css
    ├── assets/logo.svg
    └── js/                        # utils, api, wizard, solicitudes, reservas, app
```
